package com.test.summary;

public class S001_DataType_Variable {
    public static void main(String[] args) {

        // 자료형 + 변수 + 리터럴

        // 자료형 변수명 + 리터럴;

        int num = 10;

        int age;
        age = 20;

        String name = "홍길동";

        int weight , height;

        int kor = 100, eng = 90, math = 80;

    }
}
