package com.test.summary;

public class S004_Method {
    public static void main(String[] args) {

        //인자값 x 반화값x
        m1();

        //인자값O , 반환값x
        m2(3);

        //인자값x , 반환값O
        m3();
        //인자값o , 반환값 o
        m4(2);
    }
    static void m1(){

    }

    static void m2(int n) {

    }

    static int m3() {
        return 100;
    }

    static int m4(int a) {
        return 3;
    }

}
