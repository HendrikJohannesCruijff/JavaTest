package com.test.question;

public class Q009 {

    public static void main(String[] args) {
        getName("홍길동");
    }

    static void getName(String name) {
        System.out.printf("고객 : %s님", name);
    }

}
