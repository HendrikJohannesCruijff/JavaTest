package com.test.question;

public class Q018 {
    public static void main(String[] args) {
        System.out.println("양수 : "+positive(1)+"개");

    }

    static int positive(int a) {
        int count = 0;

        return count;


    }

    static int positive(int a, int b) {

        return a > 0 ? 1 : 0;

    }
}
