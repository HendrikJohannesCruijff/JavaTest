package com.test.question;

public class Q005 {
    public static void main(String[] args) {

        System.out.println("사용자가 총 1,000회 페달을 밟아 자전거가 총 2,074.708m를 달렸습니다.");
    }
}
