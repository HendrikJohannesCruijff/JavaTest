package com.test.java;

public class Ex01 {
    public static void main(String[] args) {
        int a = 5;
        if (a == 5) {
            System.out.println("d");
        } else {

        }
    }

}
