package com.test.java;

public class Ex17_Operator {
    public static void main(String[] args) {
        /*

            논리연산자
            - &&(and) , ||(or) , !(not) , ^(xor)
            - 2항연산자(&&,||,^)
            - 피연산지의 자료형은 boolean
            - 연산결과 boolean

            A && B = ?


                */

        int age = 20;
        System.out.println(age > 19 && age < 60);


    }
}
