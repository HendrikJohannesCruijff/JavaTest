package com.test.java;

public class Ex22_LocalVariable {

    public static void main(String[] args) {

        /*

        자바 변수의 종류
        1. 맴버 변수 , Member Variable

        2. 지역 변수 , Local Variable
            - 여태까지 수업한 변수

            지역 변수
            - 메서드 내에 선언한 변수
            - 변수의 선언 위치(***)

            지역변수의 생명 주기 , Life Cycle
            - 언제 태어나서 ~ 언제죽는지
                */

        int c;

        String name = "홍길동";
    }

    static void m1() {

    }
}
