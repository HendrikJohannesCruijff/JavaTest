import com.test.java.Ex02;

import java.util.*;

public class Main {
    public static void main(String[] args) {

        float aNum = 10.2F;
        System.out.printf("a의 숫자는 %f 입니다 \n",aNum);

        float bNum = 10.224F;
        System.out.printf("b의 숫자는 %f 입니다 \n",bNum);

        float cSum = 1254.2534F;
        System.out.printf("숫자의합은 %f 입니다\n", cSum);

        float dNum = 10.2F;
        System.out.printf("a의 숫자는 %f 입니다 \n",aNum);

        float eNum = 10.224F;
        System.out.printf("b의 숫자는 %f 입니다 \n",bNum);

        float fSum = 1254.2534F;
        System.out.printf("숫자의합은 %f 입니다\n", cSum);

        float gNum = 10.2F;
        System.out.printf("a의 숫자는 %f 입니다 \n",aNum);

        float hNum = 10.224F;
        System.out.printf("b의 숫자는 %f 입니다 \n",bNum);

        float iSum = 1254.2534F;
        System.out.printf("숫자의합은 %f 입니다\n", cSum);

        System.out.println("=====================================================");
        double Vertical = 100.0;

        System.out.println(" 수직의 길이는  " + Vertical + "cm입니다");

        double  df= 100.0;

        System.out.println(" 수직의 길이는  " + Vertical + "cm입니다");
        System.out.println("=======================================================");

        final byte myWeight = 90;
        System.out.printf("제 몸무게는 %d 입니다\n", myWeight);

        final byte monday = 17;
        System.out.printf("월요일은 %d일 입니다\n", myWeight);
        final byte age = 27;
        System.out.printf("제 나이는 %d살 입니다\n", age);
        final byte today = 17;
        System.out.printf("오늘은 %d일 입니다\n", today);
        final byte yesterday = 16;
        System.out.printf("어제는 %d일 입니다\n", yesterday);
        final byte pcPw = 123;
        System.out.printf(" PC 비밀번호는 %d 입니다\n", pcPw);
        final byte phonePw = 11;
        System.out.printf("휴대폰 비밀번호는 %d 입니다\n", phonePw);
        final byte buy = 2;
        System.out.printf("구매할물건의 개수는 %d 입니다\n", buy);
        final byte sell = 5;
        System.out.printf("되팔렘할 물건의개수는 %d 입니다\n", sell);

        System.out.println("=============================================");
        final short money = 1000;
        System.out.printf("현재 금액은 %d원 입니다\n", money);
        final short busMoney = 2000;
        System.out.printf("현재 버스 금액은 %d원 입니다\n", money);
        final short subMoney = 3000;
        System.out.printf("현재 지하철 금액은 %d원 입니다\n", subMoney);
        final short airMoney = 5000;
        System.out.printf("현재 항공권 금액은 %d원 입니다\n", airMoney);
        final short phoneMoney = 3341;
        System.out.printf("현재 휴대폰금액은 %d원 입니다\n", phoneMoney);
        final short mouseMoney = 2341;
        System.out.printf("현재 마우스 금액은 %d원 입니다\n", mouseMoney);
        final short keyMoney = 672;
        System.out.printf("현재 키보드 금액은 %d원 입니다\n", keyMoney);
        final short moniterMoney = 1000;
        System.out.printf("현재 모니터 금액은 %d원 입니다\n", moniterMoney);
        final short ticketMoney = 1000;
        System.out.printf("현재 티켓 금액은 %d원 입니다\n", ticketMoney);

        System.out.println("===============================================");

        int price = 5000000;
        System.out.printf("물건의 금액은 %d원 입니다\n", price);
        int door = 3;
        System.out.printf("문의 개수는%d개 입니다\n", door);
        int chrome = 1;
        System.out.printf("크롬의 개수는 %d개 입니다\n", chrome);
        int time = 4;
        System.out.printf("현재시각은 %d시 입니다\n", time);
        int hour = 2;
        System.out.printf(" %d시 입니다\n", hour);
        int minute = 20;
        System.out.printf("현재 분은 %d분 입니다\n", minute);
        int second = 60;
        System.out.printf("현재 초는 %d초입니다\n", second);
        int july = 7;
        System.out.printf("현재는 %d월 입니다\n", july);
        int key = 2;
        System.out.printf("현재 키는 %d개 입니다\n", key);


        System.out.println("======================================================");

        long pw = 1231234218937295793L;
        System.out.printf("비밀번호는 %d 입니다\n",pw);
        long firstPw = 1231234218937295793L;
        System.out.printf("첫비밀번호는 %d 입니다\n",firstPw);
        long secondPw = 2342341L;
        System.out.printf("두번쨰비밀번호는 %d 입니다\n",secondPw);
        long thirdPw = 56464323432L;
        System.out.printf("세번째 비밀번호는 %d 입니다\n",thirdPw);
        long forthPw = 1231238937295793L;
        System.out.printf("네번째 비밀번호는 %d 입니다\n",forthPw);
        long fifthPw = 1231123421893793L;
        System.out.printf("비밀번호는 %d 입니다\n",fifthPw);
        long sixPw = 1231218937295793L;
        System.out.printf("여섯번째 비밀번호는 %d 입니다\n",sixPw);
        long sevenPw = 1231234218937295793L;
        System.out.printf("일곱번째 비밀번호는 %d 입니다\n",sevenPw);
        long eightPw = 1231234218937295793L;
        System.out.printf("여덟번쨰비밀번호는 %d 입니다\n",eightPw);
        long ninePw = 1231234218937295793L;
        System.out.printf("아홉번째 비밀번호는 %d 입니다\n",ninePw);
        System.out.println("===========================================================");

        String name = "홍길동";
        System.out.printf("제 이름은 %s 입니다\n",name);
        String mouseName = "삼성";
        System.out.printf("마우스 이름은 %s 입니다\n",mouseName);
        String keyName = "삼성";
        System.out.printf("키보드 이름은 %s 입니다\n",keyName);
        String phoneName = "iphone";
        System.out.printf("휴대폰 이름은 %s 입니다\n",phoneName);
        String bagname = "eastpak";
        System.out.printf("제 가방 이름은 %s 입니다\n",bagname);
        String wifiName = "SIST_1";
        System.out.printf("와이파이 이름은 %s 입니다\n",wifiName);
        String wifiPwName = "asd";
        System.out.printf("와이파이 비번은 %s 입니다\n",wifiPwName);
        String wifiId = "zzz";
        System.out.printf("와이파이 아이디는 %s 입니다\n",wifiId);
        String julyName = "july";
        System.out.printf("7월은 %s 입니다\n",julyName);
        String middleName = "길동";
        System.out.printf("제 미들네임은 %s 입니다\n",middleName);

        System.out.println("==================================================");

        boolean b = true;
        System.out.println("b 는 " + b + "입니다");
        boolean b1 = false;
        System.out.println("b1 는 " + b1 + "입니다");
        boolean b2 = true;
        System.out.println("b2 는 " + b2 + "입니다");
        boolean b3 = false;
        System.out.println("b3 는 " + b3 + "입니다");
        boolean b4 = true;
        System.out.println("b4 는 " + b4 + "입니다");
        boolean b5 = false;
        System.out.println("b5 는 " + b5 + "입니다");
        boolean b6 = true;
        System.out.println("b6 는 " + b6+ "입니다");
        boolean b7 = false;
        System.out.println("b7 는 " + b7 + "입니다");
        boolean b8 = true;
        System.out.println("b8 는 " + b8 + "입니다");
        System.out.println("====================================");

        char c = 'C';
        System.out.println("char c 는 " + c + "입니다");
        char c1 = 'A';
        System.out.println("char c1 는 " + c1 + "입니다");
        char c2 = 'B';
        System.out.println("char c2 는 " + c2 + "입니다");
        char c3 = 'C';
        System.out.println("char c3 는 " + c3 + "입니다");
        char c4 = 'D';
        System.out.println("char c4 는 " + c4+ "입니다");
        char c5 = 'E';
        System.out.println("char c5 는 " + c5 + "입니다");
        char c6 = 'F';
        System.out.println("char c6 는 " + c6 + "입니다");
        char c7 = 'G';
        System.out.println("char c7 는 " + c7 + "입니다");
        char c8 = 'H';
        System.out.println("char c8 는 " + c8 + "입니다");



    }
}
