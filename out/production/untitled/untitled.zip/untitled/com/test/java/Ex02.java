package com.test.java;

public class Ex02 {
    public static void main(String[] args) {

        int kor = 90;
        System.out.println("kor = " + kor);

        int eng = 80 , math = 70;

        System.out.println("eng = " + eng);
        System.out.println("math = " + math);




    }
}
