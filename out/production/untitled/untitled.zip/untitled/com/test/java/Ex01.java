package com.test.java;

public class Ex01 {
    public static void main(String[] args) {
    }

}
